import java.sql.Date;

/**
 *
 * @author Alejandro
 */
public class CREDENCIAL {
    String NUMCONTROL, NOMBREALUMNO,CARRERA;
    Date FECHAEXPEDICION;
    int SEMESTRE;
    
    public CREDENCIAL(String nc, String na, String c,String f, String s){
        NUMCONTROL = nc;
        NOMBREALUMNO = na;
        CARRERA = c;
        FECHAEXPEDICION = Date.valueOf(f);
        SEMESTRE = Integer.parseInt(s);
    }
    
    public String[] toRenglon(){
        String[] vector = new String[5];
        
        vector[0]=NUMCONTROL;
        vector[1]=NOMBREALUMNO;
        vector[2]=CARRERA;
        vector[3]=""+FECHAEXPEDICION;
        vector[4]=""+SEMESTRE;
        return vector;
    }
}
