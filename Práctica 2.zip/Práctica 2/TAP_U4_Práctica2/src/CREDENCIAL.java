
import java.sql.Date;

/**
 *
 * @author Alejandro
 */
public class CREDENCIAL {
    String NUMCONTROL, NOMBREALUMNO,CARRERA;
    Date FECHAEXPEDICION;
    int SEMESTRE;
    
    public CREDENCIAL(String nc, String na, String c,Date f, int s){
        NUMCONTROL = nc;
        NOMBREALUMNO = na;
        CARRERA = c;
        FECHAEXPEDICION = f;
        SEMESTRE = s;
        
    }
    
    public String[] toRenglon(){
        String[] vector = new String[5];
        
        vector[0]=NUMCONTROL;
        vector[1]=NOMBREALUMNO;
        vector[2]=CARRERA;
        vector[3]=""+FECHAEXPEDICION;
        vector[4]=""+SEMESTRE;
        return vector;
    }
}
