
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Alejandro
 */
public class BaseDatos {
    Connection conexion;
    Statement transaccion;
    ResultSet cursor;
    String cadenaConexion="jdbc:mysql://b0jnhrvbsmk3hrqnr7hk-mysql.services.clever-cloud.com:3306/b0jnhrvbsmk3hrqnr7hk?zeroDateTimeBehavior=CONVERT_TO_NULL";
    String usuario="ujgenb4cvnfuhl74";
    String pass="o6IeXi2pHuXQlgn80zcd";
    long tiempoActual = System.currentTimeMillis();
    Date fechaActual = new Date(tiempoActual);
    
    
    public BaseDatos(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion= DriverManager.getConnection(cadenaConexion, usuario, pass);
            transaccion = conexion.createStatement();
        } catch(SQLException e){
            
        } catch(ClassNotFoundException e){
            
        }
    }
    
    public boolean insertar (CREDENCIAL c){
        String SQL_Insertar="INSERT INTO `CREDENCIAL` (`NUMCONTROL`, `NOMBREALUMNO`, "
                + "`CARRERA`, `FECHAEXPEDICION`, `SEMESTRE`) VALUES ('%NUM%','%NOM%','%CAR%','%FEC%','%SEM%');";
        SQL_Insertar=SQL_Insertar.replace("%NUM%", c.NUMCONTROL);
        SQL_Insertar=SQL_Insertar.replace("%NOM%", c.NOMBREALUMNO);
        SQL_Insertar=SQL_Insertar.replace("%CAR%", c.CARRERA);
        SQL_Insertar=SQL_Insertar.replace("%FEC%", ""+c.FECHAEXPEDICION);
        SQL_Insertar=SQL_Insertar.replace("%SEM%", ""+c.SEMESTRE);
        
        try{
            transaccion.execute(SQL_Insertar);
        }catch(SQLException e){
            return false;
        }
        
        
        return true;
    }
    
    public ArrayList<CREDENCIAL> mostrarTodos(){
        ArrayList<CREDENCIAL> datos = new ArrayList<CREDENCIAL>();
        String SQL_consulta = "SELECT * FROM `CREDENCIAL`";
        
        try{
            cursor = transaccion.executeQuery(SQL_consulta);
            
            if(cursor.next()){
                do{
                    CREDENCIAL c = new CREDENCIAL(
                        cursor.getString(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getDate(3),
                        cursor.getInt(4) 
                    );
                }while(cursor.next());
            }
        }catch(SQLException ex){
            Logger.getLogger(BaseDatos.class.getName()).log(Level.SEVERE, null, ex);
        }
        return datos;
    }
    
    public CREDENCIAL obtenerPorID(String IDaBuscar){
        String SQL_consulta = "SELECT * FROM `CREDENCIAL` WHERE ID ="+IDaBuscar;
        
        try{
            cursor = transaccion.executeQuery(SQL_consulta);
            
            if(cursor.next()){
                CREDENCIAL c = new CREDENCIAL(
                        cursor.getString(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getDate(3),
                        cursor.getInt(4)          
                    );
                return c;
            }
        } catch(SQLException ex){
            Logger.getLogger(BaseDatos.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new CREDENCIAL("","","",fechaActual,-1);
    }
    
    public boolean eliminar(String IDaEliminar){
        String SQL_eliminar = "DELETE FROM `CREDENCIAL` WHERE ID ="+IDaEliminar;
        
        try{
            transaccion.execute(SQL_eliminar);
        }catch (SQLException ex){
            return false;
        }
        return true;
    }
    
    public boolean actualizar (CREDENCIAL c){
        String SQL_actualizar="UPDATE `CREDENCIAL` SET `NUMCONTROL`='%NUM%', `NOMBREALUMNO`='%NOM%', "
                + "`CARRERA`='%CAR%', `FECHAEXPEDICION`='%FEC%', `SEMESTRE`='%SEM%' WHERE `NUMCONTROL`="+c.NUMCONTROL;
        SQL_actualizar=SQL_actualizar.replace("%NUM%", c.NUMCONTROL);
        SQL_actualizar=SQL_actualizar.replace("%NOM%", c.NOMBREALUMNO);
        SQL_actualizar=SQL_actualizar.replace("%CAR%", c.CARRERA);
        SQL_actualizar=SQL_actualizar.replace("%FEC%", ""+c.FECHAEXPEDICION);
        SQL_actualizar=SQL_actualizar.replace("%SEM%", ""+c.SEMESTRE);
        
        try{
            transaccion.executeUpdate(SQL_actualizar);
        }catch(SQLException e){
            return false;
        }
        
        
        return true;
    }
}
